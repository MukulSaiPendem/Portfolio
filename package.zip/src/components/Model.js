import React, { useRef, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, useGLTF } from '@react-three/drei';
import { AnimationMixer } from 'three';
import './Model.css';

const Model = () => {
  const group = useRef();
  const { scene, animations } = useGLTF('/model.gltf');
  const mixer = useRef();

  useEffect(() => {
    if (scene && animations.length) {
      mixer.current = new AnimationMixer(scene);
      animations.forEach((clip) => {
        mixer.current.clipAction(clip).play();
      });
    }
  }, [scene, animations]);

  useFrame((state, delta) => {
    if (mixer.current) {
      mixer.current.update(delta);
    }
  });

  return (
    <group ref={group} scale={[1.2, 1.2, 1.2]} rotation={[0, 0, 0]}>
      <primitive object={scene} />
    </group>
  );
};

const ModelCanvas = () => {
  return (
    <div className="model-container">
      <Canvas>
        <ambientLight intensity={0.5} />
        <spotLight position={[10, 10, 10]} angle={1.0} penumbra={1} />
        <pointLight position={[-10, -10, -10]} />
        <OrbitControls />
        <Model />
      </Canvas>
    </div>
  );
};

export default ModelCanvas;
