import React from 'react';
import NavBar from './components/NavBar';
import ModelCanvas from './components/Model';
import './App.css';

function App() {
  return (
    <div className="App">
      <NavBar />
      <ModelCanvas />
    </div>
  );
}

export default App;
